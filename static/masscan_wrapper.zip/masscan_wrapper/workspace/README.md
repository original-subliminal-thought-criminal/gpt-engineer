# Masscan Wrapper

A Python wrapper for the masscan tool, made by Darpanet.

## Installation

1. Install masscan on your system.
2. Clone this repository and navigate to the root directory.
3. Run `pip install .` to install the masscan-wrapper module.

## Usage

