pip install --user .
pip install --user -e .[dev]
pytest
flake8
